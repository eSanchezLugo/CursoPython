# Programación en Python ![Status badge](https://img.shields.io/badge/status-in%20progress-brightgreen)

- Contiene las sintaxis basica para programar en python.
- Control de flujos (condicionales y bucles).
- Generadores.
- Excepciones.
- Programación orientada a objetos.
- Métodos útiles y especificos.
- Modulos.


## 🔧 Instalación :

1. Clonar este proyecto.
2. Tener instalado python 3.9.
3. Tener un ambiente de desarrollo para python.


## 🛠️ Construido con :


